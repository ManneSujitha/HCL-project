package sort;
import java.util.Arrays;
public class MergeSort {
    
    public void sort(int[] array) {
        if (array == null || array.length == 0) {
            return;
        }
        
        MergeSortTask task = new MergeSortTask(array);
        task.start();
        
        try {
            task.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void merge(int[] result, int[] left, int[] right) {
        int i = 0, j = 0, k = 0;
        while (i < left.length && j < right.length) {
            if (left[i] <= right[j]) {
                result[k++] = left[i++];
            } else {
                result[k++] = right[j++];
            }
        }
        while (i < left.length) {
            result[k++] = left[i++];
        }
        while (j < right.length) {
            result[k++] = right[j++];
        }
    }
}



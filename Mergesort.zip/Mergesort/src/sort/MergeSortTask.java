package sort;

import java.util.Arrays;

public class MergeSortTask extends Thread {
    private int[] array;

    public MergeSortTask(int[] array) {
        this.array = array;
    }

    @Override
    public void run() {
        mergeSort(array);
    }

    private void mergeSort(int[] array) {
        if (array.length > 1) {
            int mid = array.length / 2;

            int[] left = Arrays.copyOfRange(array, 0, mid);
            int[] right = Arrays.copyOfRange(array, mid, array.length);

            MergeSortTask leftTask = new MergeSortTask(left);
            MergeSortTask rightTask = new MergeSortTask(right);

            leftTask.start();
            rightTask.start();

            try {
                leftTask.join();
                rightTask.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            MergeSort.merge(array, left, right);
        }
    }
}
